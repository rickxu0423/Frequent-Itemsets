## Frequent Itemsets

Use command: **python3 run.py** to run the analysis.

## The first prompt asks you to choose the method for analysis:
    1. Apriori
    2. Apriori-Improved
    3. FP-Growth

## The sechond prompt asks you to input the minimum support:
    Any number between 1 and 30000 (recommend 8000).

Use command: **python3 binCheck.py** to see binning method for the project.

The data is from: http://archive.ics.uci.edu/ml/datasets/Adult

